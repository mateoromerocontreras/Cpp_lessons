#include <iostream>

int main() {
    int puntos1 = 8;
    int puntos2 = 9;

    // Evitamos division entera usando double
    double promedio = static_cast<double>(puntos1 + puntos2) / 2.0;

    if (promedio >= 9.0) {
        std::cout << "Excelente. Promedio: " << promedio << '\n';
    } else if (promedio >= 7.0) {
        std::cout << "Aprobado. Promedio: " << promedio << '\n';
    } else {
        std::cout << "Reprobado. Promedio: " << promedio << '\n';
    }

    return 0;
}
